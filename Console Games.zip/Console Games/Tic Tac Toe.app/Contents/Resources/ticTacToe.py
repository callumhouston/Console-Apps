import time, random, sys, os
import tkinter as tk
from os import system
from tkinter import font as tkFont, messagebox


#Opening and defining the window
window = tk.Tk()
window.title("Tic Tac Toe")
window.geometry("630x635")
myFont = tkFont.Font(size=170)

#Defining whos turn it is
turn = "player"
win = "False"

#Defining all Buttons and their aspects
a1 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(a1)))
a2 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(a2)))
a3 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(a3)))
b1 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(b1)))
b2 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(b2)))
b3 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(b3)))
c1 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(c1)))
c2 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(c2)))
c3 = tk.Button(text = " ", height=1, width=2, font=myFont, command=(lambda: buttonClicked(c3)))

exitButton = tk.Button(text = "Exit Game", command=(lambda: window.destroy()))
resetButton = tk.Button(text = "Reset Game", command=(lambda: reset()))

# Defining all the positions of the buttons
a1.grid(column=0,row=0)
a2.grid(column=1,row=0)
a3.grid(column=2,row=0)
b1.grid(column=0,row=1)
b2.grid(column=1,row=1)
b3.grid(column=2,row=1)
c1.grid(column=0,row=2)
c2.grid(column=1,row=2)
c3.grid(column=2,row=2)

exitButton.grid(column=2,row=4)
resetButton.grid(column=0,row=4)

# Defining list of all winning combinaitons and orders
winList = [
    (a1,a2,a3),(a1,a3,a2),(a2,a3,a1),
    (b1,b2,b3),(b1,b3,b2),(b2,b3,b1),
    (c1,c2,c3),(c1,c3,c2),(c2,c3,c1),
    (a1,b1,c1),(a1,c1,b1),(b1,c1,a1),
    (a2,b2,c2),(a2,c2,b2),(b2,c2,a2),
    (a3,b3,c3),(a3,c3,b3),(b3,c3,a3),
    (a1,b2,c3),(a1,c3,b2),(b2,c3,a1),
    (a3,b2,c1),(a3,c1,b2),(b2,c1,a3),
]

#Defining corners and edges/middle
buttonList = [a1,a2,a3,b1,b2,b3,c1,c2,c3]
cornerList = [a1,a3,c1,c3]
edgeList = [a2,b1,b2,b3,c2]

# This function runs whenever a move is made, it checks to see if anyone has won
def checkWin():
    global win, a1, a2, a3, b1, b2, b3, c1, c2, c3
    for i in range(0,len(winList)):
        if winList[i][0]["text"] == "X" and winList[i][1]["text"] == "X" and winList[i][2]["text"] == "X" and win == "False":
            winList[i][0]["fg"] = "red"
            winList[i][1]["fg"] = "red"
            winList[i][2]["fg"] = "red"
            win = "Player"
            window.update()
            messagebox.showinfo("Win Alert", "You Won. \n Good Job!")

    for i in range(0,len(winList)):
        if winList[i][0]["text"] == "O" and winList[i][1]["text"] == "O" and winList[i][2]["text"] == "O" and win == "False":
            winList[i][0]["fg"] = "red"
            winList[i][1]["fg"] = "red"
            winList[i][2]["fg"] = "red"
            win = "Computer"
            window.update()
            messagebox.showinfo("Win Alert", "You Lost. \n Better Luck Next Time!")
 
#This function runs when it is the computers turn to move
def computersTurn():
    global turn, winList, cornerList, win, a1, a2, a3, b1, b2, b3, c1, c2, c3
    if win == "False":
    # Checking to see if there is a possible win for the computer, and if so taking it.
        for i in range(0,len(winList)):
            if turn == "computer":
                if winList[i][0]["text"] == "O" and winList[i][1]["text"] == "O" and winList[i][2]["text"] == " ":
                    winList[i][2]["text"] = "O"
                    turn = "player"
                
    # Checking if there is a possible win for the Player, if there is then blocking it.
        if turn == "computer":
            for i in range(0,len(winList)):
                if winList[i][0]["text"] == "X" and winList[i][1]["text"] == "X" and winList[i][2]["text"] == " ":
                    if turn == "computer":
                        winList[i][2]["text"] = "O"
                        turn = "player"

    # If there is no wins to take/block, the computer attempts to place it in a random corner
        if turn == "computer":
            possibleCorners = []
            for i in range(0,len(cornerList)):
                if cornerList[i]["text"] == " ": 
                    possibleCorners += str(i)
            if len(possibleCorners) > 0:
                cornerList[int(random.choice(possibleCorners))]["text"] = "O"
                turn = "player"

    # If there are no corners available, the computer randomly places it
        if turn == "computer":
            possibleEdges = []
            for i in range(0,len(edgeList)):
                if edgeList[i]["text"] == " ": 
                    possibleEdges += str(i)
            if len(possibleEdges) > 0:
                edgeList[int(random.choice(possibleEdges))]["text"] = "O"
                turn = "player"
            else:
                win = "Draw"
                window.update()
                messagebox.showinfo("Tie Alert", "You Tied. \n Better Luck Next Time!")
        
        checkWin()

# This function runs when a player clicks a button, it checks if button is free, takes it, then mchecks if theuy won and moves to computer's turn.
def buttonClicked(b):
    global turn, a1, a2, a3, b1, b2, b3, c1, c2, c3
    if win == "False":
        if turn == "player":
            if b["text"] == " ":
                b["text"] = "X"
                checkWin()
                turn = "computer"
                computersTurn()
            else:
                messagebox.showerror("Error Message", "Please select an empty box")

# This function resets the board and restarts the game
def reset():
    global buttonList, win, turn
    win = "False"
    turn = "player"
    for i in range(0,len(buttonList)):
        buttonList[i]["text"] = " "
        buttonList[i]["fg"] = "black"

window.mainloop()