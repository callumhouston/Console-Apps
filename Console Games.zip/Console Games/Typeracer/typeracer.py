import time, random, sys, os
from pynput import keyboard
from os import system
from termcolor import colored
from quote_examples import quotes

#Defining variables 
correctWords = 0
startTime = 0
endTime = 0
typed = ""
timerStarted = "False"
typingFinished = "False"

#This function clears the screen of all text
def clear_screen():
    system("clear")

#This function simulates typing text, this function was written and inspired by Finn Jones in 2020.
def typing(text): 
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.03)
    print("")

#This function chooses a random quote from a list of quotes (sourced from typeracer.org) and defines the author, book/game and quote.
def random_quote():
    global author, book, quote
    quote_number = random.randint(0,(len(quotes)-1))
    author = quotes[quote_number][0]
    book = quotes[quote_number][1]
    quote = quotes[quote_number][2]

#This function runs after the user has finished typing, It shows credit, WPM and accuracy
def end_function():
    global correctWords, accuracy
    typing(colored("\n   You just typed a quote from " + author + " in '" + book + "'", "cyan"))
    typing(colored("   You typed at a speed of " + str(round(len(typed.split())/((endTime-startTime)/60), 2)) + " WPM. (" + str(len(typed.split())) + " words in " + str(round(endTime-startTime,2)) + " seconds)", "yellow"))
    for i in range(0, len(typed.split())):
        if typed.split()[i] == quote.split()[i]:
            correctWords += 1
    accuracy = round(correctWords/len(typed.split())*100,2)
    typing(colored("   You were " + str(accuracy) + "% Accurate (" + str(correctWords) + "/" + str(len(quote.split())) + " words correct)", "magenta"))
    typing(colored("\n27Press Enter to Exit", "blue"))
    input("")
    exit()

#This function runs whenever you press a key due to a listener. It adds to the users typed string and prints/checks it against the quote
def on_press(key):
    global typed, quote, typingFinished, timerStarted, startTime
    if key != keyboard.Key.shift:
        if key == keyboard.Key.esc:
            return False
        try:
            k = key.char
        except:
            k = key.name
        if k == "backspace":
            typed = typed[0:len(typed)-1]
        elif k == "space":
            typed += " "
        else:
            typed += k
            if timerStarted == "False":
                startTime = time.time()
                timerStarted = "True"
        if k == "space":
            clear_screen()
            for i in range(0, len(typed.split())):
                if typed.split()[i] == quote.split()[i]:
                    print(colored(quote.split()[i]+" ", "green"), end="", flush=True)
                else:
                    print(colored(quote.split()[i]+" ", "red"), end="", flush=True)
            if len(typed.split()) < len(quote.split()):
                print(colored(quote.split()[len(typed.split())]+" ", "yellow"), end="", flush=True)
            print(" ".join([word for word in quote.split()[len(typed.split())+1:len(quote.split())]]))
            if len(typed.split()) == len(quote.split()):
                typingFinished = "True"
                return False

listener = keyboard.Listener(on_press=on_press)

#Starting the Actual Program
clear_screen()
random_quote()
print(colored(quote.split()[0], "yellow") + " " + " ".join([word for word in quote.split()[1:len(quote.split())]]))
listener.start()
listener.join() 
endTime = time.time()
end_function()

## Add "Would you like to save this run" then add top spread with WPM accuracy and quote
## Add "thanks for using typerace"