import time, random, sys, os
from os import system
from termcolor import colored

#Defining variables
use = "Y"
numbers = "unchosen"
n_1 = 0
n_2 = 0

#This function clears the screen of all text
def clear_screen():
    system("clear")

#This function simulates typing text, this function was written and inspired by Finn Jones in 2020.
def typing(text): 
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.03)

#This function allows the user to choose the mathematic operation they'd like to use
def use_calculator():
    global numbers
    global n_1
    global n_2
    typing(colored("Input a symbol to choose one of the following operations:", "blue") + colored("\n\n [+] Addition \n [-] Subtraction \n [*] Multiplication \n [/] Division \n [^] Power \n", "yellow") )
    operation_chosen = input("")
    clear_screen()

    #Allowing user to input desired numbers if not already chosen, if nubers are not valid integers, choice will run again.
    while numbers == "unchosen":
        typing(colored("Number 1: ", "blue"))
        n_1 = input("")
        typing(colored("\nNumber 2: ", "blue"))
        n_2 = input("")
        try:
            n_1 = int(n_1)
            numbers = "chosen"
        except ValueError:
            clear_screen()
            typing(colored("Please enter valid integers \n", "red"))

    #Checking what operation the user entered, and using that operation with the chosen numbers. If invalid operation was chosen, choice will run again.
    if operation_chosen == "+":
        clear_screen()
        typing(colored(str(n_1) + " + " + str(n_2) + " = " + str(int(n_1) + int(n_2)) ,"green"))
    elif operation_chosen == "-":
        clear_screen()
        typing(colored(str(n_1) + " - " + str(n_2) + " = " + str(int(n_1) - int(n_2)) ,"green"))
    elif operation_chosen == "*":
        clear_screen()
        typing(colored(str(n_1) + " multiplied by " + str(n_2) + " = " + str(int(n_1) * int(n_2)) ,"green"))
    elif operation_chosen == "/":
        clear_screen()
        typing(colored(str(n_1) + " divided by " + str(n_2) + " = " + str(int(n_1) / int(n_2)) ,"green"))
    elif operation_chosen == "^":
        clear_screen()
        typing(colored(str(n_1) + " to the power of " + str(n_2) + " = " + str(int(n_1) ** int(n_2)) ,"green"))
    else:
        clear_screen()
        typing(colored("Please enter a valid operation \n", "red"))
        use_calculator()

    #Asking user if they'd lke to reuse the calculator, then reseeting it for use or ending loop.
    typing(colored("\nWould you like to use the calculator again?", "blue") + colored("\n\n [Y] Yes \n [other] No \n", "yellow"))
    use = input("")
    if use.upper() == "Y":
        numbers = "unchosen"
        clear_screen()
        use_calculator()

#Clearing the screen to start with a nice clean interface
clear_screen()

#Greeting the user and giving options of what they want to calculate
typing(colored("Hello and Welcome to console calculator. \n", "green"))

#Directing to the use_calculator function, where the guts of the code is stored
use_calculator()

#Ending Calculator use
clear_screen()
typing(colored("Thank you for using the console calculator.", "blue"))